import {configureStore} from '@reduxjs/toolkit'
import { appReducer } from './reducer'
import logger from 'redux-logger'
export const store=configureStore({
    reducer:{
        appReducer
    },
    middleware:[logger]
})