import { gql } from '@apollo/client';

// Define mutation
export const SAVE_QUE = gql`
  mutation Mutation($data: queObj!) {
    saveQue(data: $data)
  }
`;

