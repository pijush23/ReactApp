import React, { useEffect, useState } from 'react'
import { inputControlsArr } from './config'
import { Input } from '../InputControls/Input'
import { TextArea } from '../InputControls/TextArea'
import { Select } from '../InputControls/Select'
import { fnValidate } from './validate'
import { Loader } from '../Loader/Loader'
import { toast } from 'react-toastify';
import {useMutation} from '@apollo/client'
import { SAVE_QUE } from '@/gqQueries/saveQue'
export const Question = () => {
  const [inputControls,setInputControls]=useState(inputControlsArr)

  const [callSaveQueMutation,{loading,data,error}]=useMutation(SAVE_QUE)

  useEffect(()=>{
     if(!loading){
        if(data){
            const _inputControls=JSON.parse(JSON.stringify(inputControls))
            const {acknowledged,insertedId} =data.saveQue
            if(acknowledged && insertedId){
                toast.success('Successfully Inserted')
                _inputControls.forEach((obj)=>{
                    obj.val=''
                 })
                 setInputControls(_inputControls)
            }else{
                toast.error('Not inserted , try again.')
            }
        }
        if(error){
            toast.error(error.message);
        }
     }
  },[loading,data,error])

  const fnChange=(eve)=>{
   
     const {value,name} =eve.target
     let _inputControls=JSON.parse(JSON.stringify(inputControls))
     let inputControlObj=_inputControls.find((obj)=>obj.name==name)
     inputControlObj.val=value
     fnValidate(inputControlObj)
     setInputControls(_inputControls)
  }

  const fnSave=()=>{
    let dataObj={}
    let _inputControls=JSON.parse(JSON.stringify(inputControls))
    _inputControls.forEach((obj)=>{
        dataObj[obj.name]=obj.val
        fnValidate(obj)
    })
    let isInvalid=_inputControls.some((obj)=>{
        return obj.isShowErrorMsg
    })
    setInputControls(_inputControls)
    if(isInvalid)return;
    callSaveQueMutation({variables:{data:dataObj}})
  }
  return (
    <div className='container-fluid mt-5'>
        {
            inputControls.map((obj,index)=>{
                switch(obj.tag){
                    case 'input':
                        return <Input key={index} fnChange={fnChange} {...obj} />
                    case 'textarea':
                        return <TextArea key={index} fnChange={fnChange} {...obj} />
                    case 'select':
                        return <Select key={index} fnChange={fnChange} {...obj} />
                        
                }
            })
        }
        <div className='row'>
            <div className='offset-sm-5 col-sm-7'>
                <button onClick={fnSave} className='btn btn-primary'>SAVE</button>
            </div>
        </div>
       {loading &&  <Loader ></Loader>}
    </div>
  )
}
