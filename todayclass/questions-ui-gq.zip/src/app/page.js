"use client";
import { Header } from "@/components/Header/Header"
import { Footer } from "@/components/Footer/Footer"
import { Question } from "@/components/Question/Question"
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';
import { ToastContainer } from 'react-toastify'

const client = new ApolloClient({
  uri: 'http://localhost:2020/graphql',
  cache: new InMemoryCache(),
});
export default function App() {
  return (
   <div>
      <ApolloProvider client={client}>
          <Header ></Header>
          <Question />
          <Footer />
      </ApolloProvider>
      <ToastContainer
      position="top-right"
      autoClose={5000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
      theme="light"
      />
{/* Same as */}
<ToastContainer />
   </div>      
  )
}
