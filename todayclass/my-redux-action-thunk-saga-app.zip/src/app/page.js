"use client"
import Image from 'next/image'
import styles from './page.module.css'
import { userAction } from './actions/userAction'
import {Provider} from 'react-redux'
import { appStore } from './store/appStore'
import { commentsThunkAction } from './actions/commentsThukAction'
import {bindActionCreators} from '@reduxjs/toolkit'
export default function Home() {
  const fnGetUsers=()=>{
    userAction()
  }
  const fnGetComments=()=>{
    bindActionCreators(commentsThunkAction,appStore.dispatch)()
  }

  const fnGetPosts=()=>{
    debugger;
    appStore.dispatch({
      type:'GET_POSTS'
    })
  }

  const fnGetPhotos=()=>{
    appStore.dispatch({
      type:'GET_PHOTOS'
    })
  }

  return (
    <Provider store={appStore}>
      <h1>Action</h1>
       <input type='button' onClick={fnGetUsers} value='get users' />
       <h1>Thunk</h1>
       <input type='button' onClick={fnGetComments} value='get comments' />
       <h1>Saga</h1>
       <input type='button' onClick={fnGetPosts} value='get posts' />
       <input type='button' onClick={fnGetPhotos} value='get photos' />
    </Provider>
   
  )
}
