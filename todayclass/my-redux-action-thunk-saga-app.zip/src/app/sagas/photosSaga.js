import {takeLatest,call,put} from 'redux-saga/effects'
import { ServerCall } from '../ServerCall/ServerCall'
function* getPhotos(){
  const res= yield call(ServerCall.sendGetReq,'https://jsonplaceholder.typicode.com/photos')
  yield put({
    type:'PHOTOS_UPDATE',
    payload:res.data
  })
}

function* insertPhoto(){

}


function* photosSaga(){
    // 2 saga
   yield takeLatest('GET_PHOTOS',getPhotos)
   yield takeLatest('INSERT_PHOTO',insertPhoto)
}

export default photosSaga