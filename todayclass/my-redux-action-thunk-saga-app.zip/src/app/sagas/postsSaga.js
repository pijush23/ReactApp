import { takeLatest,call,put } from "redux-saga/effects"
import { ServerCall } from '../ServerCall/ServerCall'

function* deletePost(){

}

function* getPosts(){
    const res= yield call(ServerCall.sendGetReq,'https://jsonplaceholder.typicode.com/posts')
    yield put({
      type:'POSTS_UPDATE',
      payload:res.data
    })
}

function* postsSaga(){
    // 2 function register
    yield takeLatest('GET_POSTS',getPosts)
    yield takeLatest('DELETE_POST',deletePost)

}

export default postsSaga