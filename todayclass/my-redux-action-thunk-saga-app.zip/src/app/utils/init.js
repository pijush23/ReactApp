export const usersInit={
    users:[]
}

export const commentsInit={
    comments:[]
}

export const sagaInit={
    posts:[],
    photos:[]
}


