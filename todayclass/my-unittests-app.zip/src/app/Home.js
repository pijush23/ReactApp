import React from 'react'

export const Home = () => {
  return (
    <div>
    <span data-testid='ss'>Sachin</span>
    <h1>Kohli</h1>
    <h1>uv</h1>
    <label for="username-input">Username</label>
    <input value='uv' placeholder='name' id="username-input" />

    <p title="panth">Panth</p>
    
  </div>
  )
}
