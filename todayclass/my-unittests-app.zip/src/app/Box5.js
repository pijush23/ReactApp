import React from 'react'


const Box=({id,clr,goToNextLine,width})=>{
    return <>
     <div style={{background:clr,width:width}} className='box'>{clr}</div>
     {goToNextLine&&<div></div>}
    </>
}
export const Box5 = () => {
  const data=[
    {
        id:'1',
        clr:'red',
        goToNextLine:false,
        width:150
    },
    {
        id:'2',
        clr:'blue',
        goToNextLine:true,
        width:150
    },
    {
        id:'3',
        clr:'yellow',
        goToNextLine:false,
        width:100
    },
    {
        id:'3',
        clr:'green',
        goToNextLine:false,
        width:100
    },
    {
        id:'1',
        clr:'purple',
        goToNextLine:false,
        width:100
    }
  ]
  return (
    <div style={{width:'300px'}}>
       {
        data.map((obj)=><Box {...obj} />)
       }
    </div>
  )
}
