import { Count } from "./Count";
import React from "react";
import {render,screen} from '@testing-library/react'
import '@testing-library/jest-dom'
import user from '@testing-library/user-event'
describe('Count component', () => { 
    it('renders correctly',()=>{
        render(<Count />)
        const h1Ele=screen.getByRole('heading');
        expect(h1Ele).toBeInTheDocument()
        const btnEle=screen.getByRole('button');
        expect(btnEle).toBeInTheDocument()
    })
    it('child initial count',()=>{
        render(<Count />)
        const h1Ele=screen.getByRole('heading');
        expect(h1Ele).toHaveTextContent('0')
    })
    it('check count value on button click',async()=>{
        user.setup();
        render(<Count />)
        const btnEle=screen.getByRole('button');
        const h1Ele=screen.getByRole('heading');
        await user.click(btnEle)
        expect(h1Ele).toHaveTextContent('1')
    })
 })