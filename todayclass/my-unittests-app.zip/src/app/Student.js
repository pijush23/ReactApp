import React from 'react'

export const Student = ({name}) => {
  return (
    <h1 role='h1'>{name ? `Hellow...${name}` : 'Hellow...Guest' }</h1>
  )
}
