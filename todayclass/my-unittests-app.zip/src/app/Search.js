import React, { useState } from 'react'

const data=[{
    id:1,
    name:'Sachin',
    loc:'mumbai'
  },
  {
    id:2,
    name:'Dhoni',
    loc:'Ranchi'
  },{
    id:3,
    name:'Kohli',
    loc:'Delhi'
  }]
export const Search = () => {
  const [players,setPlayers]=useState(data)

  const fnChange=(eve)=>{
      const val=eve.target.value;
      const filteredData=data.filter((obj)=>{
        return obj.name.includes(val)
      })
      setPlayers(filteredData.sort((obj1,obj2)=>{
    
        if(obj1.name < obj2.name){
           return -1
        }
        return 1;
    }))
  }
  return (
    <div>
        <p>Search:<input onChange={fnChange} /></p>
        <ul>
        {
            players.map((obj,ind)=>{
                return <li key={ind}>{obj.name}</li>
            })
        }
        </ul>
    </div>
  )
}
