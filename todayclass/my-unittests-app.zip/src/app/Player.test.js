import { Player } from "./Player";
import React from "react";
import {render,screen} from '@testing-library/react'   

describe("Player component test", ()=>{
    it("name check",()=>{
        render(<Player />)
        const element=screen.getByRole("p");
        expect(element.textContent).toBe("Sachin")
    })
    it("Location check",()=>{
        render(<Player />)
        const element=screen.getByRole("h1");
        expect(element.textContent).toBe("Mumbai")
    })
})