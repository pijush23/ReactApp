"use client";
import React, { useState } from "react"
import { Home } from "./Home"
import { Player } from "./Player"
import { Student } from "./Student"
import { Search } from "./Search"
import { Count } from "./Count";
import { Increment } from "./Increment";
import { Box5 } from "./Box5";
import { IncDec } from "./IncDec";
import { TestApi } from "./TestApi";
import { GetUsers } from "./GetUsers";
export default function App() {
  const [cnt,setCnt]=useState(0)
  const f1=()=>{
    setCnt(cnt+1)
  }
  const f2=()=>{
    setCnt(cnt-1)
  }

  return (
    <div>
      {/* <IncDec cnt={cnt} fnInc={f1} fnDec={f2} /> */}
      {/* <TestApi url='https://jsonplaceholder.typicode.com/comments/2' /> */}
      <GetUsers />
    </div>
  )
}
