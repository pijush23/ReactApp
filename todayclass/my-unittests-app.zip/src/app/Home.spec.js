import {Home} from "./Home";
import React from "react";
import {render,screen} from '@testing-library/react';
import '@testing-library/jest-dom';

describe("Home component tests",()=>{
    it("check span element static text",()=>{
        render(<Home />)
        const element =screen.getByText("Sachin");
        expect(element).toBeInTheDocument()
    })
    it("check b element static text",()=>{
        render(<Home />)
        const element =screen.getByRole('heading',{
            name:'Kohli'
        })
        expect(element).toHaveTextContent('Kohli')
    })
    it("check textbox value",()=>{
        render(<Home />)
        const element =screen.getByRole('textbox')
        expect(element).toHaveValue('uv')
    })
    it("check getByLabelText textbox value",()=>{
        render(<Home />)
        const element =screen.getByLabelText('Username')
        expect(element).toHaveValue('uv')
    })
    it("check getByPlaceholderText textbox value",()=>{
        render(<Home />)
        const element =screen.getByPlaceholderText('name')
        expect(element).toHaveValue('uv')
    })
    it("check getByDisplayValue textbox value",()=>{
        render(<Home />)
        const element =screen.getByDisplayValue('uv')
        expect(element).toHaveValue('uv')
    })
    it("check getByTitle textbox value",()=>{
        render(<Home />)
        const element =screen.getByTitle('panth')
        expect(element).toHaveTextContent('Panth')
    })
    it("check getByTitle textbox value",()=>{
        render(<Home />)
        const element =screen.getByTitle('panth')
        expect(element).toHaveTextContent('Panth')
    })
    it("check getByTestId textbox value",()=>{
        render(<Home />)
        const element =screen.getByTestId('ss')
        expect(element).toHaveTextContent('Sachin')
    })
})