import React, { useState } from 'react'
import axios from 'axios'
export const GetUsers = () => {
  const [data,setData]=useState()
  const fnGetUsers=async()=>{
   const res= await axios.get('https://jsonplaceholder.typicode.com/users/1');
   setData(res.data);
   
  }
  return (
    <div>
         {data && <>
           <h1 role='h1'>{data.name}</h1>
           <h2 role='h2'>{data.phone}</h2>
         </>}
        <button onClick={fnGetUsers}>Get Users</button>
    </div>
  )
}
