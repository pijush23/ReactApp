import React from "react";

import { IncDec } from "./IncDec";
import user from '@testing-library/user-event'
import {render,screen} from '@testing-library/react'

import '@testing-library/jest-dom'

describe("Inc Dec test",()=>{
    it("render correctly",()=>{
        render(<IncDec />)
        const h1Ref=screen.getByRole('heading')
        expect(h1Ref).toBeInTheDocument();
        const incBtn=screen.getByRole('button',{
            name:'Inc'
        });
        expect(incBtn).toBeInTheDocument();
        const decBtn=screen.getByRole('button',{
            name:'Dec'
        });
        expect(decBtn).toBeInTheDocument();

    })
    test("Initial h1 value",()=>{
        render(<IncDec cnt={10} />)
        const h1Ref=screen.getByRole('heading')
        expect(h1Ref).toHaveTextContent(10)
    })
    test('check evend handlers method call',async()=>{
        user.setup()
        const incFn=jest.fn();
        const decFn=jest.fn();
        render(<IncDec cnt={10} fnInc={incFn} fnDec={decFn} />)
        const incBtn=screen.getByRole('button',{
            name:'Inc'
        });
        const decBtn=screen.getByRole('button',{
            name:'Dec'
        });
        await user.click(incBtn)
        await user.click(incBtn)
        await user.click(incBtn)
        await user.click(decBtn)
        expect(incFn).toHaveBeenCalledTimes(3);
        expect(decFn).toHaveBeenCalledTimes(1);

    })
})