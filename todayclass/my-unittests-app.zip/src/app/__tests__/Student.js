import { Student } from "../Student";
import React from "react";
import {render,screen} from '@testing-library/react'

describe('Student component tests', () => { 

    it('With props',()=>{
        render(<Student /> )
        const ele=screen.getByRole('h1');
        expect(ele.textContent).toBe("Hellow...Guest")
    })

    it('With out props',()=>{
        render(<Student name='Dhoni' />)
        const ele=screen.getByRole('h1');
        expect(ele.textContent).toBe("Hellow...Dhoni");
    })
 })