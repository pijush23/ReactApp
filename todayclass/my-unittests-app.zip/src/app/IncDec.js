import React from 'react'

export const IncDec = ({cnt,fnInc,fnDec}) => {
  return (
    <div>
        <h1>{cnt}</h1>
        <button onClick={fnInc}>Inc</button>
        <button onClick={fnDec}>Dec</button>
    </div>
  )
}
