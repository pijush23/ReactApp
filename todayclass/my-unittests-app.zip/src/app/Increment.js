import React,{useEffect, useState,useRef} from 'react'

export const Increment = () => {
  // let cnt=10;
  const [cnt,setCnt]=useState(10)
  let interval;
  const ref=useRef()
  const fnDecrement=()=>{
        setCnt((val)=>{
            if(val==1){
                clearInterval(interval)
            }
            return val-1 
        })
        // ref.current.innerText=cnt
        // cnt=cnt-1;
        // if(cnt==0){
        //     clearInterval(interval)
        // }
  }
  useEffect(()=>{
    interval=window.setInterval(()=>{
        fnDecrement()
    },1000)
  },[])

 
//   const fnClick=()=>{
   
//     for(let i=0;i<=5;i++){
//         //setCnt(cnt+1)
//         setCnt((val)=>{
//             return val+1
//         })
//     }
//   }
  return (
    <div>
        <h1>{cnt}</h1>
        {/* <h1 ref={ref}></h1> */}
        {/* <button onClick={fnClick}>click</button> */}
    </div>
  )
}
