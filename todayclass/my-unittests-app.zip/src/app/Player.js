import React from 'react'

export const Player = () => {
  return (
    <div>
        <p role="p">Sachin</p>
        <h1 role="h1">Mumbai</h1>
    </div>
  )
}
