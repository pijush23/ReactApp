import React, { useState } from 'react'

export const Count = () => {
    const [cnt,setCnt]=useState(0)
  return (
    <div>
        <h1>{cnt}</h1>
        <button onClick={()=>setCnt(cnt+1)}>click</button>
    </div>
  )
}
