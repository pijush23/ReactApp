import Image from 'next/image'
import styles from './page.module.css'
import { Players } from './Players'

export default function Home() {
  const f1=()=>{
    alert('ss')
  }
  return (
   <div>
    <Players
     name="Sachin" 
     amount={1000}
     isShow={true}
     players={['Sachin','Dhoni',10]}
     std={{name:'s1',rno:1}}
     students={[{name:'s1',rno:1},{name:'s1',rno:1}]}
     fn={f1}
     opt="S"
     myStyles={{color:'red', fontSize:'20px'}}
     />
   </div>
  )
}
