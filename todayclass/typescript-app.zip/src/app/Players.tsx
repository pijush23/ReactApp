import React,{useState} from 'react'

type stdObj={
    name:string,
    rno:number
}
type propsObj={
    name:string,
    amount:number,
    isShow:boolean,
    players:(string|number)[]
    std:stdObj,
    students:stdObj[],
    fn:()=>void,
    opt:'S'|'D',
    myStyles:React.CSSProperties
}
export const Players = (props:propsObj) => {
    const [name,setName]=useState<string>('Sachin')
  return (
    <div>
        <p>{props.name}</p>
        <p>{props.amount}</p>
        {props.isShow && <div>Dhoni</div>}

    </div>
  )
}
