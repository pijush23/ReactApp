import {gql} from '@apollo/client'

export const  GET_QUE=gql`
    query GetQuestions {
        getQuestions {
        que
        _id
        opt1
        opt2
        opt3
        opt4
        type
        ans
        }
    }
`