'use client';
import styles from './page.module.css'
import {Header} from '@/components/Header'
import { Footer } from '@/components/Footer'
import { Test } from '@/components/Test';
import { ApolloClient, InMemoryCache, ApolloProvider } from '@apollo/client';

const client = new ApolloClient({
  uri: 'http://localhost:2020/',
  cache: new InMemoryCache(),
});
export default function App() {
  return (
    <ApolloProvider client={client}>
      <Header />
      <Test />
      <Footer />
   </ApolloProvider>
  )
}
