'use client';
import styles from './page.module.css'
import {Header} from '@/components/Header'
import { Footer } from '@/components/Footer'
import { Test } from '@/components/Test';
export default function App() {
  return (
   <div>
    <Header />
    <Test />
    <Footer />
   </div>
  )
}
