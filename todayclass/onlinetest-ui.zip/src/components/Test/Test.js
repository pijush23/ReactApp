import React, { useEffect, useState } from 'react'
import styles from './Test.module.css';
import axios from 'axios';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import { Loader } from '../Loader/Loader';
import {MyModal} from 'nit-modal'
const Question=({que,qno,opt1,opt2,opt3,opt4,type, _id, fn})=>{
    const options=['A','B','C','D']
    return <Card className='mb-3'>
        <CardContent>
            <p><b>{qno}. {que}</b></p>
            {
                [opt1,opt2,opt3,opt4].map((val,ind)=>{
                    return <div key={ind}>{type==='S' ? <input value={options[ind]} type='radio' onChange={fn} name={_id} /> : <input onChange={fn} name={_id} type='checkbox' value={options[ind]} />}<span className='ms-2'>{val}</span></div>
                })
            }
        </CardContent>
    </Card>
}
export const Test = () => {
  const [data,setData]=useState([])
  const [keyObj,setKeyObj]=useState({}) 
  const [ansObj,setAnsObj]=useState({})  
  const [isShowLoader,setIsShowLoader]=useState(true)
  const [modalObj,setModalObj]=useState({fnModalBtnClick:()=>{},isShowModal:false,text:'',isShowYesBtn:true,isShowCloseBtn:true,})
 useEffect(()=>{
    fnGetQuestions()
 },[])

 const fnGetQuestions=async ()=>{
    const res=await axios.get('http://localhost:2020/que/get-que')
    const {status,data:questions} =res
    if(status==200){
        setIsShowLoader(false);
       let _keyObj={}
       questions.forEach(({_id,ans})=>{
        _keyObj[_id]=ans
       })
       setKeyObj(_keyObj)
       setData(questions) 
    }else{
        setData([])
        setIsShowLoader(false);
    }
 }
  const fnChange=(eve)=>{
        const {name,value,type,checked}=eve.target
        if(type==='checkbox'){
            let chckedValues=ansObj[name]?ansObj[name].split(""):[]
            if(checked){
                chckedValues.push(value)
            }else{
                let index=chckedValues.indexOf(value)
                chckedValues.splice(index,1)
            }
            ansObj[name]=chckedValues.sort().join("")
        }else{
         ansObj[name]=value
        }
  }
  const fnModalBtnClick=(opt)=>{
    if(opt=='close'){
        setModalObj({...modalObj,isShowModal:false})
    }else{
        let marks=0
        Object.keys(ansObj).forEach((qno)=>{
            if(ansObj[qno]===keyObj[qno]){
                marks++
            }
        })
        setModalObj({
            ...modalObj,
            isShowModal:true,
            fnModalBtnClick:fnModalBtnClick,
            isShowYesBtn:false,
            text:`You Got ${marks} Mark(s).`
        })
    }
     
  }
  const fnSubmit=()=>{
    setModalObj({
        ...modalObj,
        isShowModal:true,
        fnModalBtnClick:fnModalBtnClick,
        text:'R u sure...'
    })
  
  }
  return (
    <div className='mb-5'>
        {isShowLoader ? <Loader />:
        <>
        {
            data.map((obj,index)=>{
                return <Question fn={fnChange} key={index} qno={index+1}  {...obj} />
            })
        }
       <Button onClick={fnSubmit} variant="contained">Submit</Button>
       </>
    }

      <MyModal {...modalObj}  />
    </div>
  )
}
