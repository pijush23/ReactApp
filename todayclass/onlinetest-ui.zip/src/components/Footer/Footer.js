import React from 'react'
import styled from 'styled-components'


const FooterDiv=styled.div`
    position: fixed;
    text-align: center;
    background:blue;
    color:white;
    width:100%;
    bottom:0px;
`
export const Footer = () => {
  return (
    <FooterDiv>&copy; rights belongs to me.</FooterDiv>
  )
}


