const {gql} =require('apollo-server-express');

const typeDefs=gql`

   scalar JSON
   input queObj{
    que:String!,
    opt1:String!,
    opt2:String!,
    opt3:String!,
    opt4:String!,
    type:String!,
    ans:String!
   }
   type Query{
     fnHellow(name:String!):String!
   }
   type Mutation{
      saveQue(data:queObj!):JSON!
   }

`

module.exports=typeDefs;