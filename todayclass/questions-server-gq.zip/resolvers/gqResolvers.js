const mongodb=require('mongodb')

const resolvers={
    Query:{
        fnHellow:(a,args)=>{
            return "Hellow"+args.name
        }
    },
    Mutation:{
        saveQue:async(a,args,c,d)=>{
           
    try{
        // take the data from req
            const dataObj=args.data
        // connect with db
            // const url="mongodb://localhost:27017"
            const url="mongodb+srv://nit9am:nit9am@9am.odctmdy.mongodb.net/"
            const mongodbClient=mongodb.MongoClient
            const server=await mongodbClient.connect(url)
            const db=server.db('school')
            const collection=db.collection('questions')
             //perform requred opearions
            const result=await collection.insertOne(dataObj)
            // prepare and send res back to client
            return result;
        }catch(e){
            console.log(e)
            return e;
        }
        }
    }
}

module.exports=resolvers;