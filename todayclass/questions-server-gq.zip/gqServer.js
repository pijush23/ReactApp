const {ApolloServer} =require('apollo-server-express')
const express=require('express')
const cors=require('cors')
const typeDefs=require('./schemas/gqSchemas.js');
const resolvers=require('./resolvers/gqResolvers.js')

const app=express()
app.use(cors())

const server=new ApolloServer({typeDefs,resolvers})
server.start()
.then(()=>{
    server.applyMiddleware({app})
    app.listen(2020,()=>{
        console.log('server started')
    })
})
.catch(()=>{
    
})
