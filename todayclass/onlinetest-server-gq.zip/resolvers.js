import mongodb from 'mongodb'
export const resolvers={
    Query:{
        getName:(a,b,c,d)=>{
            return "Hello Sachin"
        },
        getQuestions:async (a,b,c,d)=>{
                // conn with db 
                try{
                    var url="mongodb+srv://nit9am:nit9am@9am.odctmdy.mongodb.net/"
                    var mongoClient=mongodb.MongoClient;
                    const server=await mongoClient.connect(url)
                    const db=server.db('school')
                    var collection=db.collection('questions')
                    var result=await collection.aggregate([{ $sample: { size: 10} }]).toArray()
                    return result;
                }catch(e){
                console.log('Exception raised')
                console.log(e)
                return e;                }

        }

    }
}
