

export const typeDefs=`#graphql
 type queObj{
    _id:String!
    que:String!
    opt1:String!
    opt2:String!
    opt3:String!
    opt4:String!
    type:String!
    ans:String!
 }
 type Query{
    getName:String!
    getQuestions:[queObj]!
 }
`

