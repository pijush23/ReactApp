import React from 'react'

const home = () => {
  return (
    <h1>This is home page.</h1>
  )
}

export default home
