import React from 'react'

const contact = () => {
  return (
    <h1>This is contact page.</h1>
  )
}

export default contact