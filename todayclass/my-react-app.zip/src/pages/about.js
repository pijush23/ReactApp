import React from 'react'

const about = () => {
  return (
    <h1>This is about page.</h1>
  )
}

export default about