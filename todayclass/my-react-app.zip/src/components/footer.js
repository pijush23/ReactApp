import React from 'react'

 const footer = () => {
  return (
    <div className='footer text-white text-center bg-primary'>&copy; rights belongs to me.</div>
  )
}

export default footer