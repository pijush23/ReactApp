import React from 'react'

const header = () => {
  return (
    <div className="bg-primary text-center text-white header">My First React Application</div>
  )
}

export default header